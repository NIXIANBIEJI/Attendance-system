# 学生考勤系统

## 简介：

- 毕设：《基于Java的学生考勤系统》

## 开发环境

- SpringBoot
- MyBatis-Plus
- MySQL 8.0
- Maven
- Shiro

## 说明

- main 分支：包含完整功能，技术栈SpringBoot+Mybatis-Plus
- develop 分支：基于 main 分支开发
- shiro 分支：使用 shiro 重构
