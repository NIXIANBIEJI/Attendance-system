package com.weizujie.attendance.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.weizujie.attendance.entity.Admin;
import org.springframework.stereotype.Repository;

/**
 * @author weizujie
 */
public interface AdminMapper extends BaseMapper<Admin> {
}
