package com.weizujie.attendance.utils;

import java.util.List;

/**
 * @author weizujie
 */
public class Data {
    private List<Integer> ids ;

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }
}
